function growingWord() {

  //TODO...
}